#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/////////////////////////// Estruturas ///////////////////////////
typedef struct { //Data
    int Dia;
    int Mes;
    int Ano;
} Data;

typedef struct { //Registro
    char *Nome; 
    int Idade;
    char *RG;
    Data *Entrada;
} Registro;

typedef struct Elista { //Elista 
    Registro *dados;
    struct Elista *proximo;
} Elista;

typedef struct { //Lista
    Elista *primeiro;
    int qtd;
} Lista;

typedef struct Efila{ //Efila
    Registro *dados;
    struct Efila *proximo;
}Efila;

typedef struct { //Fila
    Efila *head;
    Efila *tail;
    int qtd;
}Fila;

typedef struct { //Operacoes
    char tipo_operacao[15];
    Registro *dados;
} Operacao;

typedef struct Eoperacao { //Eoperacao
    Operacao *operacao;
    struct Eoperacao *proximo;
} Eoperacao;

typedef struct { //Pilha
    Eoperacao *topo;
    int qtd;
} Pilha;

typedef struct Vertice{ //Vertice
    Registro *dados;
    int valor;
    struct Vertice* esq;
    struct Vertice* dir;
    struct Vertice* pai;
} Vertice;

typedef struct Arvore{ //Arvore
    Vertice* raiz;
    int qtde;
} Arvore;


/////////////////////////// Inicializar struct ///////////////////////////

Data *inicializa_data(int dia, int mes, int ano) {
    Data *data = malloc(sizeof(Data));
    data->Dia = dia;
    data->Mes = mes;
    data->Ano = ano;
    return data;
}

Registro *inicializar_registro(const char *nome, int idade, const char *rg, Data *data) {
    Registro *registro = malloc(sizeof(Registro));
    registro->Nome = malloc(strlen(nome) + 1); 
    strcpy(registro->Nome, nome);
    registro->Idade = idade;
    registro->RG = malloc(strlen(rg) + 1);
    strcpy(registro->RG, rg);
    registro->Entrada = data;
    return registro;
}

Lista *inicializa_lista() {
    Lista *lista = malloc(sizeof(Lista));
    lista->primeiro = NULL;
    lista->qtd = 0;
    return lista;
}

Elista *inicializa_elista(Registro *registro) {
    Elista *elista = malloc(sizeof(Elista));
    elista->dados = registro;
    elista->proximo = NULL;
    return elista;
}

Efila *inicializa_efila(Registro *registro){
    Efila *efila = malloc(sizeof(Efila));
    efila->dados = registro;
    efila->proximo = NULL;
    return efila;
}

Fila *inicializa_fila(){
    Fila *fila = malloc(sizeof(Fila));
    fila->head = NULL;
    fila->tail = NULL;
    fila->qtd = 0;
    return fila;
}
Pilha *inicializa_pilha() {
  Pilha *pilha = malloc(sizeof(Pilha));
  pilha->topo = NULL;
  pilha->qtd = 0;
  return pilha;
}

void empilhar_operacao(Pilha *pilha, const char *tipo_operacao, Registro *registro) {
  Operacao *nova_operacao = malloc(sizeof(Operacao));
  strcpy(nova_operacao->tipo_operacao, tipo_operacao);
  nova_operacao->dados = registro;

  Eoperacao *novo_elemento = malloc(sizeof(Eoperacao));
  novo_elemento->operacao = nova_operacao;
  novo_elemento->proximo = pilha->topo;

  pilha->topo = novo_elemento;
  pilha->qtd++;
}

Vertice *cria_vertice(Registro *dados, int valor){
    Vertice* novo = malloc(sizeof(Vertice));
    novo->dir = NULL;
    novo->esq = NULL;
    novo->pai = NULL;
    novo->dados = dados;
    novo->valor = valor;

    return novo;
}

Arvore *cria_arvore(){
    Arvore* arvore = malloc(sizeof(Arvore));
    arvore->raiz = NULL;
    arvore->qtde = 0;

    return arvore;
}

/////////////////////////// Menu ///////////////////////////

void menu() {
    printf("1 - Cadastrar\n");
    printf("2 - Atendimento\n");
    printf("3 - Pesquisa\n");
    printf("4 - Desfazer\n");
    printf("5 - Salvar\n");
    printf("6 - Carregar\n");
    printf("7 - Sobre\n");
    printf("8 - Sair\n");
}

/////////////////////////// Cadastrar ///////////////////////////

//Menu opcao cadastrar
void opcao1() {
    printf("1 - Cadastrar novo paciente\n");
    printf("2 - Consultar paciente cadastrado\n");
    printf("3 - Mostrar lista completa\n");
    printf("4 - Atualizar dados de paciente\n");
    printf("5 - Remover paciente\n");
}
///////funcao de cadastrar
void cadastrar(Lista *lista, const char *nome, int idade, const char *rg, Data *data) {
    Registro *novo = inicializar_registro(nome, idade, rg, data);
    Elista *nova_elista = inicializa_elista(novo);
    Elista *atual = lista->primeiro;
    Elista *anterior = NULL;
    if (lista->qtd == 0) {
        lista->primeiro = nova_elista;
    } else {
        while (atual != NULL) {
            anterior = atual;
            atual = atual->proximo;
        }
        anterior->proximo = nova_elista;
    }
    lista->qtd++; //adiciona na lista de pessoas cadastradas no final da lista
}


//Procurar especifico o cliente pelo rg
void procurar_paciente(Lista *lista, const char *rg) {
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        if (strcmp(atual->dados->RG, rg) == 0) { //compara com rg até achar o certo
            printf("Paciente encontrado:\n");
            printf("Nome: %s\n", atual->dados->Nome);
            printf("Idade: %d\n", atual->dados->Idade);
            printf("Data de entrada: %d/%d/%d\n", atual->dados->Entrada->Dia, atual->dados->Entrada->Mes, atual->dados->Entrada->Ano);
            return;
        }
        atual = atual->proximo;
    }
    printf("Paciente não encontrado.\n");
    return; //percorre a lista pra achar o rg correto
}

//mostra a lista completa
void mostrar_lista(Lista *lista) {
    Elista *atual = lista->primeiro;
    if(atual==NULL){
      printf("Nenhum paciente na lista \n");
    }
    while (atual != NULL) {
        printf("Nome: %s\n", atual->dados->Nome);
        printf("Idade: %d\n", atual->dados->Idade);
        printf("Data de entrada: %d/%d/%d\n", atual->dados->Entrada->Dia, atual->dados->Entrada->Mes, atual->dados->Entrada->Ano);
        printf("\n");
        atual = atual->proximo;
    }
}
int procurar_atualizar(Lista *lista, const char *rg){ //procura o paciente pelo rg, se ele existir retorna 1, senao retorna 0, será utilizado para funções como atualização e enfileiramento
    Elista *atual = lista->primeiro;
    while(atual != NULL){
        if (strcmp(atual->dados->RG, rg) == 0) {
            return 1;
        }
        atual = atual->proximo;
    }
    return -1;
}

//atualizar informacoes do paciente
void atualizar_paciente(Lista *lista, const char *nome, const char *rg, int idade, Data *data){
  Elista *atual = lista->primeiro;
  while(atual != NULL){
      if(strcmp(atual->dados->RG, rg) == 0){
          free(atual->dados->Nome);
          atual->dados->Nome = malloc(strlen(nome) + 1);
          strcpy(atual->dados->Nome, nome);

          atual->dados->Idade = idade;

          free(atual->dados->Entrada);
          atual->dados->Entrada = data;

          printf("Usuario atualizado com sucesso\n");
          return; //troca informações do paciente utilizando os ponteiros
      }
      atual = atual->proximo; //acha o paciente pelo rg, se encontrado atualiza suas informações pelas novas
  }
}

//remove o paciente
void remover_cliente(Lista *lista, const char *rg) {
  Elista *atual = lista->primeiro;
  Elista *anterior = NULL;
  while (atual != NULL && strcmp(atual->dados->RG, rg) != 0) {
      anterior = atual;
      atual = atual->proximo;
  }
  if (atual == NULL) {
      printf("Paciente não encontrado.\n");
      return;
  }
  if (anterior == NULL) {
      lista->primeiro = atual->proximo;
  } else {
      anterior->proximo = atual->proximo;
  }
  free(atual->dados->Nome);
  free(atual->dados->RG);
  free(atual->dados->Entrada);
  free(atual->dados);
  free(atual);
  lista->qtd--; //tira paciente da lista
  printf("Paciente removido com sucesso.\n");
}
/////////////////////////// Atendimento ///////////////////////////

//Menu opcao atendimento
void opcao2() {
    printf("1 - Enfileirar paciente\n");
    printf("2 - Desenfileirar paciente\n");
    printf("3 - Mostrar fila\n");
}
//Enfileirar paciente na fila
void enfileirar(Lista *lista, Fila *fila, Pilha *pilha, const char *rg) {
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        if (strcmp(atual->dados->RG, rg) == 0) {
            Registro *copia_registro = inicializar_registro(
                atual->dados->Nome,
                atual->dados->Idade,
                atual->dados->RG,
                inicializa_data(
                    atual->dados->Entrada->Dia,
                    atual->dados->Entrada->Mes,
                    atual->dados->Entrada->Ano
                )
            );
            Efila *novo = inicializa_efila(copia_registro); //salvamos as informações
            if (fila->qtd == 0) {
                fila->head = novo;
            } else {
                fila->tail->proximo = novo;
            }
            fila->tail = novo;
            fila->qtd++;
          empilhar_operacao(pilha, "enfileirar", copia_registro);
            printf("Paciente enfileirado com sucesso.\n");
            return;
        }
        atual = atual->proximo;
    }
    printf("Paciente não encontrado na lista.\n"); //procura paciente pelo rg e adiciona na fila, empilhamos ela pra poder desfazer posteriormente
}
//tira o paciente do inicio da fila
void desenfileirar(Fila *fila, Pilha *pilha) {
    if (fila->qtd == 0) {
        printf("Nao existe nenhum paciente na fila\n");
        return;
    }

    //guarda o paciente a ser desenfileirado
    Efila *temp = fila->head;
    Registro *copia_registro = inicializar_registro(
        temp->dados->Nome,
        temp->dados->Idade,
        temp->dados->RG,
        inicializa_data(
            temp->dados->Entrada->Dia,
            temp->dados->Entrada->Mes,
            temp->dados->Entrada->Ano
        )
    );
    fila->head = fila->head->proximo;
    if (fila->qtd== 1) {
        fila->tail = NULL;
    }
    fila->qtd--;
    //empilha a operação de desenfileiramento para desfazer
    empilhar_operacao(pilha, "desenfileirar", copia_registro);
    printf("O cliente %s foi retirado da fila\n", temp->dados->Nome);
    free(temp->dados->Nome);
    free(temp->dados->RG);
    free(temp->dados->Entrada);
    free(temp->dados);
    free(temp);
}
//mostra a fila (printa informações)
void mostrar_fila(Fila *fila){
    Efila *atual = fila->head;
    printf("Head -> \n");
    while(atual != NULL){
        printf("Nome: %s\n", atual->dados->Nome);
        printf("Idade: %d\n", atual->dados->Idade);
        printf("Data de entrada: %d/%d/%d\n", atual->dados->Entrada->Dia, atual->dados->Entrada->Mes, atual->dados->Entrada->Ano);
        printf("\n");
        atual = atual->proximo;
    }
    printf("<- Tail\n");
}
//////////////////////desfazer///////////////
void desfazer_operacao(Pilha *pilha, Fila *fila) {
    if (pilha->qtd == 0) {
        printf("Nenhuma operacao para desfazer.\n");
        return;
    }
    Eoperacao *elemento = pilha->topo;
    Operacao *operacao = elemento->operacao;
    int confirmacao; //desfazer enfileirar
     if (strcmp(operacao->tipo_operacao, "enfileirar") == 0) {
        printf("Deseja mesmo desfazer a operacao de enfileirar do paciente %s? (1 - Sim, 2 - Nao): ", operacao->dados->Nome);
        scanf("%d", &confirmacao); //se pessoa realmente quiser desfazer ele volta a operação
        if (confirmacao == 1) {
            Efila *temp = fila->head;
            Efila *anterior = NULL;
            while (temp != NULL && temp->proximo != NULL) {
                anterior = temp;
                temp = temp->proximo;
            }

            if (temp != NULL) {
                if (anterior == NULL) {
                    fila->head = NULL;
                    fila->tail = NULL;
                } else {
                    anterior->proximo = NULL;
                    fila->tail = anterior;
                }
                fila->qtd--;
                free(temp->dados->Nome);
                free(temp->dados->RG);
                free(temp->dados->Entrada);
                free(temp->dados);
                free(temp);
                printf("Operacao de enfileirar desfeita.\n");
            }
        } else {
            printf("Operacao de enfileirar nao desfeita.\n");
            return;
        }
    } else if (strcmp(operacao->tipo_operacao, "desenfileirar") == 0) { //desfazer desenfileirar
        printf("Deseja mesmo desfazer a operacao de desenfileirar do paciente %s? (1 - Sim, 2 - Nao): ", operacao->dados->Nome);
        scanf("%d", &confirmacao);
        if (confirmacao == 1) {
            Efila *novo = inicializa_efila(operacao->dados);
            if (fila->qtd == 0) {
                fila->head = novo;
                fila->tail = novo;
            } else {
                novo->proximo = fila->head;
                fila->head = novo;
            }
            fila->qtd++;
            printf("Operacao de desenfileirar desfeita.\n");
        } else {
            printf("Operacao de desenfileirar nao desfeita.\n");
            return;
        }
    } 
    pilha->topo = elemento->proximo;
    free(operacao);
    free(elemento);
    pilha->qtd--;
}

/////////////////////////// Pesquisa ///////////////////////////
//Menu opcao pesquisa
void opcao3() {
    printf("1 - Mostrar registro ordenados por ano de registro\n");
    printf("2 - Mostrar registro ordenados por mes de registro\n");
    printf("3 - Mostrar registro ordenados por dia de registro\n");
    printf("4 - Mostrar registro ordenados por idade do paciente\n");
}

//liberar arvore
void liberar_arvore(Vertice* vertice) {
    if (vertice != NULL) {
        liberar_arvore(vertice->esq);
        liberar_arvore(vertice->dir);
        free(vertice);
    }
}

//print na ordem
void in_ordem(Vertice *raiz) {
    if(raiz != NULL){
      in_ordem(raiz->esq);
      printf("Nome: %s\n", raiz->dados->Nome);
      printf("Idade: %d\n", raiz->dados->Idade);
      printf("RG: %s\n", raiz->dados->RG);
      printf("Data de Entrada: %02d/%02d/%04d\n", 
             raiz->dados->Entrada->Dia, 
             raiz->dados->Entrada->Mes, 
             raiz->dados->Entrada->Ano);
      printf("------------------------\n");
      in_ordem(raiz->dir);
    }
}

//insere o registro do paciente na arvore, a arvore eh organizada com base na data informada
void inserir(Arvore* arvore, int data, Registro *dados){
    Vertice *novo = cria_vertice(dados, data);
    Vertice *atual = arvore->raiz;
    Vertice *anterior = NULL;

    while(atual != NULL){
        anterior = atual;
        if(data < atual->valor){
            atual = atual->esq;
        }
        else{
            atual = atual->dir;
        }
    }

    if(anterior == NULL){
        arvore->raiz = novo;
    }
    else if(data < anterior->valor){
        novo->pai = anterior;
        anterior->esq = novo;
    }
    else{
        novo->pai = anterior;
        anterior->dir = novo;
    }
}

void buscarAno(Lista *lista) { //insere todos os pacientes na árvore, ordenando pela data de entrada, exibe ela em ordem crescente de ano
    Arvore *arvore = cria_arvore();
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        int data = atual->dados->Entrada->Ano;
        inserir(arvore, data, atual->dados);
        atual = atual->proximo;
    }
    in_ordem(arvore->raiz);
    liberar_arvore(arvore->raiz);
    free(arvore);
}

void buscarMes(Lista *lista) { //ordena os pacientes por mês de entrada
    Arvore *arvore = cria_arvore();
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        int data = atual->dados->Entrada->Mes;
        inserir(arvore, data, atual->dados);
        atual = atual->proximo;
    }
    in_ordem(arvore->raiz);
    liberar_arvore(arvore->raiz);
    free(arvore);
}

void buscarDia(Lista *lista) { //ordena os pacientes pela data de entrada (dia)
    Arvore *arvore = cria_arvore();
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        int data = atual->dados->Entrada->Dia;
        inserir(arvore, data, atual->dados);
        atual = atual->proximo;
    }
    in_ordem(arvore->raiz);
    liberar_arvore(arvore->raiz);
    free(arvore);
}

void buscarIdade(Lista *lista) { //ordena pacientes pela idade
    Arvore *arvore = cria_arvore();
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        int data = atual->dados->Idade;
        inserir(arvore, data, atual->dados);
        atual = atual->proximo;
    }
    in_ordem(arvore->raiz);
    liberar_arvore(arvore->raiz);
    free(arvore);
}

/////////////////////////// Carregar / Salvar ///////////////////////////
void salvar_lista(Lista *lista, FILE *arquivo) { //alva as informações dos pacientes
    Elista *atual = lista->primeiro;
    while (atual != NULL) {
        fprintf(arquivo, "%s;%d;%s;%d/%d/%d\n",
                atual->dados->Nome,
                atual->dados->Idade,
                atual->dados->RG,
                atual->dados->Entrada->Dia,
                atual->dados->Entrada->Mes,
                atual->dados->Entrada->Ano);
        atual = atual->proximo;
    }
    printf("Lista salva com sucesso.\n"); //salva no arquivo
}

void carregar_lista(Lista *lista, FILE *arquivo) {
    char nome[50], rg[15];
    int idade, dia, mes, ano;
    while (fscanf(arquivo, " %49[^;];%d;%14[^;];%d/%d/%d\n",
                  nome, &idade, rg, &dia, &mes, &ano) != EOF) {
        Data *data = inicializa_data(dia, mes, ano);
        cadastrar(lista, nome, idade, rg, data); 
        printf("Nome: %s\nIdade: %d\nRG: %s\nData de Entrada: %02d/%02d/%04d\n\n",
               nome, idade, rg, dia, mes, ano);
    } //carrega todas informações obtidas até agora
}

void ler_arquivo(FILE *arquivo){ //lê as informacoes dos pacientes que ja temos e printa
    char nome[50], rg[15];
    int idade, dia, mes, ano;
    while(fscanf(arquivo, " %49[^;];%d;%14[^;];%d/%d/%d\n", nome, &idade, rg, &dia, &mes, &ano) != EOF){
        printf("Nome: %s\nIdade: %d\nRG: %s\nData de Entrada: %02d/%02d/%04d\n\n", nome, idade, rg, dia, mes, ano);
    }
}

//////////////////////////SOBRE///////////////////////
void sobre() {
    printf("Nome dos alunos: Julian Ryu Takeda e Manuella Filipe Peres\n"); //um pouco sobre a equipe
    printf("Ciclo: 4 Ciclo\n");
    printf("Curso: Ciencia da Computacao\n");
    printf("Disciplina: Estrutura de Dados\n");
    printf("Data: 1 de novembro de 2024\n");
}
/////////////////////////////////////////////////////

int main(void) {
    //inicializando tudo pra funcionar e chama cada função do menu conforme printado
    Lista *lista = inicializa_lista(); 
    Fila *fila = inicializa_fila();
    Pilha *pilha = inicializa_pilha();
    FILE *arquivo = fopen("Arquivo.txt", "r");
    if (arquivo != NULL) {
        carregar_lista(lista, arquivo);
        fclose(arquivo);
    } else {
        printf("Nenhum dado anterior encontrado para carregar.\n");
    }

    int opcao = 0;
    //enquanto a opção nao for sair
    while (opcao != 8) { 
        menu();
        scanf("%d", &opcao);

        if (opcao == 1) { //cadastrar
            printf("\n");
            opcao1();
            int opcao1;
            scanf("%d", &opcao1);
            if (opcao1 == 1) {
                char nome[50];
                int idade;
                char rg[15];
                int dia, mes, ano;

                printf("Digite o nome do paciente: ");
                scanf(" %[^\n]s", nome);

                printf("Digite a idade do paciente: ");
                scanf("%d", &idade);

                printf("Digite o RG do paciente: ");
                scanf("%s", rg);

                printf("Digite a data de entrada do paciente\n");
                printf("Dia: ");
                scanf("%d", &dia);
                printf("Mes: ");
                scanf("%d", &mes);
                printf("Ano: ");
                scanf("%d", &ano);

                Data *data = inicializa_data(dia, mes, ano);
              cadastrar(lista, nome, idade, rg, data); 
            }
            else if (opcao1 == 2) {
                char rg[15];
                printf("Digite o RG do paciente: ");
                scanf("%s", rg);
                procurar_paciente(lista, rg);
            } 
            else if (opcao1 == 3) {
                mostrar_lista(lista);
            } 
            else if(opcao1 == 4){
                char rg[15];
                printf("Digite o RG do paciente: ");
                scanf("%s", rg);

                if(procurar_atualizar(lista, rg) == 1){
                    char nome[50];
                    int idade;
                    int dia, mes, ano;

                    printf("Digite o novo nome do paciente: ");
                    scanf(" %[^\n]s", nome);

                    printf("Digite a nova idade do paciente: ");
                    scanf("%d", &idade);

                    printf("Digite a data de entrada do paciente\n");
                    printf("Dia: ");
                    scanf("%d", &dia);
                    printf("Mes: ");
                    scanf("%d", &mes);
                    printf("Ano: ");
                    scanf("%d", &ano);

                    Data *data = inicializa_data(dia, mes, ano);
                    atualizar_paciente(lista, nome, rg, idade, data);
                }
                else{
                    printf("Paciente nao cadastrado\n");
                }
            }
            else if (opcao1 == 5) {
                char rg[15];
                printf("Digite o RG do paciente: ");
                scanf("%s", rg);
                remover_cliente(lista, rg);
            }
        } 
        else if(opcao == 2){
            //atendimento
            printf("\n");
            opcao2();
            int opcao2;
            scanf("%d", &opcao2);
            if(opcao2 == 1){
                char rg[15];
                printf("Digite o RG do paciente: ");
                scanf("%s", rg);
                enfileirar(lista, fila, pilha, rg);
            }
            else if(opcao2 == 2){
                desenfileirar(fila, pilha);
            }
            else if(opcao2 == 3){
                mostrar_fila(fila);
            }
        }
        else if (opcao == 3){ 
            //filtros
            printf("\n");
            opcao3();
            int opcao3;
            scanf("%d", &opcao3);
            if(opcao3 == 1){
                buscarAno(lista);
            }
            else if(opcao3 == 2){
                buscarMes(lista);
            }
            else if(opcao3 == 3){
                buscarDia(lista);
            }
            else if(opcao3 == 4){
                buscarIdade(lista);
            }
        }
        else if (opcao == 4) { 
            //desfazer
            if (pilha->topo != NULL) {
                desfazer_operacao(pilha, fila);
            } else {
                printf("Não há operações para desfazer.\n");
            }
        }
        else if (opcao == 5) {
            //salvar
            arquivo = fopen("Arquivo.txt", "w");
            if (arquivo != NULL) {
                salvar_lista(lista, arquivo);
                fclose(arquivo);
            } else {
                printf("Erro ao salvar os dados no arquivo.\n");
            }
        }
        else if(opcao==6){
            //carregar
            arquivo = fopen("Arquivo.txt", "r");
            if (arquivo != NULL) {
                ler_arquivo(arquivo);
                fclose(arquivo);
            } else {
                printf("Nenhum arquivo encontrado para carregar.\n");
            }
        }
        else if(opcao==7){
            //sobre a equipe
            sobre();
        }
    }
    //caso a opcao for 8 ele sai do programa
    return 0;
}
